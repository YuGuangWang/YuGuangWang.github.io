%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% CELM for Diabetes %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear,clc
close all
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Type==0 for regression; Type==1 for classification
Type=1;
NumberofNeurons=20;
%Numberofdata=300;
Numberoftesttime=20;
ActivationFunction='sig';
%%%%%%%%%%% Obtain Random Dataset
diabetes5_data;     %   randomly generate new training and testing data for every trial of simulation
TrainingData_File='diabetes_train';
TestingData_File='diabetes_test';
%ablone_data('AbloneData1');
%%%%%%%%%%% Load Draining Dataset
train_data=load(TrainingData_File);
T=train_data(:,1)';
P=train_data(:,2:size(train_data,2))';
clear train_data;                                   %   Release raw training data array
%%%%%%%%%%% Load Desting Dataset
test_data=load(TestingData_File);
TV.T=test_data(:,1)';
TV.P=test_data(:,2:size(test_data,2))';
clear test_data;                                    %   Release raw testing data array


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%   Learn by CELM   %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
CELM_test=zeros(Numberoftesttime,1);
CELM_train=zeros(Numberoftesttime,1);
CELM_train_time=zeros(Numberoftesttime,1);
CELM_testing_time=zeros(Numberoftesttime,1);
CELM_TY=[];
CELM_Y=[];
wb = waitbar(0,'1','Name','CELM...');    


for rnd = 1 : Numberoftesttime
    
    waitbar(rnd/Numberoftesttime,wb,sprintf('%d',rnd));
    
    diabetes5_data;     %   randomly generate new training and testing data for every trial of simulation

    fprintf('\n====== CELM trial %d ======\n',rnd);
    [learn_time, test_time, train_accuracy, test_accuracy, CELM_Y_temp, CELM_TY_temp] =...
        CELM(TrainingData_File,TestingData_File,1,NumberofNeurons,ActivationFunction);
    CELM_test(rnd,1)=test_accuracy;
    CELM_train(rnd,1)=train_accuracy;
    CELM_train_time(rnd,1)=learn_time;
    CELM_testing_time(rnd,1)=test_time;
    CELM_TY=[CELM_TY CELM_TY_temp'];
    CELM_Y=[CELM_Y,CELM_Y_temp'];
end
close(wb);

fprintf('\n====== CELM result summary ======\n');
CELM_AverageTrainingTime=mean(CELM_train_time)
CELM_StandardDeviationofTrainingTime=std(CELM_train_time)
CELM_AvergeTestingTime=mean(CELM_testing_time)
CELM_StandardDeviationofTestingTime=std(CELM_testing_time)
CELM_AverageTrainingAccuracy=mean(CELM_train)
CELM_StandardDeviationofTrainingAccuracy=std(CELM_train)
CELM_AverageTestingAccuracy=mean(CELM_test)
CELM_StandardDeviationofTestingAccuracy=std(CELM_test)
CELM_TY_0=mean(CELM_TY');
CELM_Y_0=mean(CELM_Y');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%   Training by ELM   %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ELM_test=zeros(Numberoftesttime,1);
ELM_train=zeros(Numberoftesttime,1);
ELM_train_time=zeros(Numberoftesttime,1);
ELM_testing_time=zeros(Numberoftesttime,1);
ELM_TY=[];
ELM_Y=[];
wb = waitbar(0,'1','Name','ELM...');    


for rnd = 1 : Numberoftesttime
    
    waitbar(rnd/Numberoftesttime,wb,sprintf('%d',rnd));
    
    diabetes5_data;     %   randomly generate new training and testing data for every trial of simulation

    fprintf('\n====== ELM trial %d ======\n',rnd);
    [learn_time, test_time, train_accuracy, test_accuracy, ELM_Y_temp, ELM_TY_temp] =...
        ELM(TrainingData_File,TestingData_File,1,NumberofNeurons,ActivationFunction);
    ELM_test(rnd,1)=test_accuracy;
    ELM_train(rnd,1)=train_accuracy;
    ELM_train_time(rnd,1)=learn_time;
    ELM_testing_time(rnd,1)=test_time;
    ELM_TY=[ELM_TY ELM_TY_temp'];
    ELM_Y=[ELM_Y,ELM_Y_temp'];
end
close(wb);

fprintf('\n====== ELM result summary ======\n');
ELM_AverageTrainingTime=mean(ELM_train_time)
ELM_StandardDeviationofTrainingTime=std(ELM_train_time)
ELM_AvergeTestingTime=mean(ELM_testing_time)
ELM_StandardDeviationofTestingTime=std(ELM_testing_time)
ELM_AverageTrainingAccuracy=mean(ELM_train)
ELM_StandardDeviationofTrainingAccuracy=std(ELM_train)
ELM_AverageTestingAccuracy=mean(ELM_test)
ELM_StandardDeviationofTestingAccuracy=std(ELM_test)
ELM_TY_0=mean(ELM_TY');
ELM_Y_0=mean(ELM_Y');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% Plot the accuracy rate curve of ELM  %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
plot(1:Numberoftesttime,ELM_train_time)
title('Learning time of ELM')

%saveas(gcf,'CELM_Diabetes_ELM_time','fig')
saveas(gcf,'CELM_Diabetes_ELM_time','png')
saveas(gcf,'CELM_Diabetes_ELM_time','eps')

figure
plot(1:Numberoftesttime,ELM_train)
title('Training accuracy of ELM')

%saveas(gcf,'CELM_Diabetes_ELM_train','fig')
saveas(gcf,'CELM_Diabetes_ELM_train','png')
saveas(gcf,'CELM_Diabetes_ELM_train','eps')

figure
plot(1:Numberoftesttime,ELM_test)
title('Testing accuracy of ELM')

%saveas(gcf,'CELM_Diabetes_ELM_test','fig')
saveas(gcf,'CELM_Diabetes_ELM_test','png')
saveas(gcf,'CELM_Diabetes_ELM_test','eps')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% Plot the accuracy rate curve of CELM  %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
plot(1:Numberoftesttime,CELM_train_time)
title('Learning time of CELM')

%saveas(gcf,'CELM_Diabetes_CELM_time','fig')
saveas(gcf,'CELM_Diabetes_CELM_time','png')
saveas(gcf,'CELM_Diabetes_CELM_time','eps')

figure
plot(1:Numberoftesttime,CELM_train)
title('Training accuracy of CELM')

%saveas(gcf,'CELM_Diabetes_CELM_train','fig')
saveas(gcf,'CELM_Diabetes_CELM_train','png')
saveas(gcf,'CELM_Diabetes_CELM_train','eps')

figure
plot(1:Numberoftesttime,CELM_test)
title('Testing accuracy of CELM')

%saveas(gcf,'CELM_Diabetes_CELM_test','fig')
saveas(gcf,'CELM_Diabetes_CELM_test','png')
saveas(gcf,'CELM_Diabetes_CELM_test','eps')

save Diabetes_mean_CELM.mat