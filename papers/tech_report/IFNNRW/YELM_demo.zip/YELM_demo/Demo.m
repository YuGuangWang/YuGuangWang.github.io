%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% YELM for Diabetes %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear,clc
close all
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Type==0 for regression; Type==1 for classification
Type=1;
NumberofNeurons=20;
%Numberofdata=300;
Numberoftesttime=20;
ActivationFunction='sig';
%%%%%%%%%%% Obtain Random Dataset
diabetes5_data;     %   randomly generate new training and testing data for every trial of simulation
TrainingData_File='diabetes_train';
TestingData_File='diabetes_test';
%ablone_data('AbloneData1');
%%%%%%%%%%% Load Draining Dataset
train_data=load(TrainingData_File);
T=train_data(:,1)';
P=train_data(:,2:size(train_data,2))';
clear train_data;                                   %   Release raw training data array
%%%%%%%%%%% Load Desting Dataset
test_data=load(TestingData_File);
TV.T=test_data(:,1)';
TV.P=test_data(:,2:size(test_data,2))';
clear test_data;                                    %   Release raw testing data array


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%   Learn by YELM   %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
YELM_test=zeros(Numberoftesttime,1);
YELM_train=zeros(Numberoftesttime,1);
YELM_train_time=zeros(Numberoftesttime,1);
YELM_testing_time=zeros(Numberoftesttime,1);
YELM_TY=[];
YELM_Y=[];
wb = waitbar(0,'1','Name','YELM...');    


for rnd = 1 : Numberoftesttime
    
    waitbar(rnd/Numberoftesttime,wb,sprintf('%d',rnd));
    
    diabetes5_data;     %   randomly generate new training and testing data for every trial of simulation

    fprintf('\n====== YELM trial %d ======\n',rnd);
    [learn_time, test_time, train_accuracy, test_accuracy, YELM_Y_temp, YELM_TY_temp] =...
        YELM(TrainingData_File,TestingData_File,1,NumberofNeurons,ActivationFunction);
    YELM_test(rnd,1)=test_accuracy;
    YELM_train(rnd,1)=train_accuracy;
    YELM_train_time(rnd,1)=learn_time;
    YELM_testing_time(rnd,1)=test_time;
    YELM_TY=[YELM_TY YELM_TY_temp'];
    YELM_Y=[YELM_Y,YELM_Y_temp'];
end
close(wb);

fprintf('\n====== YELM result summary ======\n');
YELM_AverageTrainingTime=mean(YELM_train_time)
YELM_StandardDeviationofTrainingTime=std(YELM_train_time)
YELM_AvergeTestingTime=mean(YELM_testing_time)
YELM_StandardDeviationofTestingTime=std(YELM_testing_time)
YELM_AverageTrainingAccuracy=mean(YELM_train)
YELM_StandardDeviationofTrainingAccuracy=std(YELM_train)
YELM_AverageTestingAccuracy=mean(YELM_test)
YELM_StandardDeviationofTestingAccuracy=std(YELM_test)
YELM_TY_0=mean(YELM_TY');
YELM_Y_0=mean(YELM_Y');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%   Training by ELM   %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ELM_test=zeros(Numberoftesttime,1);
ELM_train=zeros(Numberoftesttime,1);
ELM_train_time=zeros(Numberoftesttime,1);
ELM_testing_time=zeros(Numberoftesttime,1);
ELM_TY=[];
ELM_Y=[];
wb = waitbar(0,'1','Name','ELM...');    


for rnd = 1 : Numberoftesttime
    
    waitbar(rnd/Numberoftesttime,wb,sprintf('%d',rnd));
    
    diabetes5_data;     %   randomly generate new training and testing data for every trial of simulation

    fprintf('\n====== ELM trial %d ======\n',rnd);
    [learn_time, test_time, train_accuracy, test_accuracy, ELM_Y_temp, ELM_TY_temp] =...
        ELM(TrainingData_File,TestingData_File,1,NumberofNeurons,ActivationFunction);
    ELM_test(rnd,1)=test_accuracy;
    ELM_train(rnd,1)=train_accuracy;
    ELM_train_time(rnd,1)=learn_time;
    ELM_testing_time(rnd,1)=test_time;
    ELM_TY=[ELM_TY ELM_TY_temp'];
    ELM_Y=[ELM_Y,ELM_Y_temp'];
end
close(wb);

fprintf('\n====== ELM result summary ======\n');
ELM_AverageTrainingTime=mean(ELM_train_time)
ELM_StandardDeviationofTrainingTime=std(ELM_train_time)
ELM_AvergeTestingTime=mean(ELM_testing_time)
ELM_StandardDeviationofTestingTime=std(ELM_testing_time)
ELM_AverageTrainingAccuracy=mean(ELM_train)
ELM_StandardDeviationofTrainingAccuracy=std(ELM_train)
ELM_AverageTestingAccuracy=mean(ELM_test)
ELM_StandardDeviationofTestingAccuracy=std(ELM_test)
ELM_TY_0=mean(ELM_TY');
ELM_Y_0=mean(ELM_Y');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% Plot the accuracy rate curve of ELM  %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
plot(1:Numberoftesttime,ELM_train_time)
title('Learning time of ELM')

%saveas(gcf,'YELM_Diabetes_ELM_time','fig')
saveas(gcf,'YELM_Diabetes_ELM_time','png')
saveas(gcf,'YELM_Diabetes_ELM_time','eps')

figure
plot(1:Numberoftesttime,ELM_train)
title('Training accuracy of ELM')

%saveas(gcf,'YELM_Diabetes_ELM_train','fig')
saveas(gcf,'YELM_Diabetes_ELM_train','png')
saveas(gcf,'YELM_Diabetes_ELM_train','eps')

figure
plot(1:Numberoftesttime,ELM_test)
title('Testing accuracy of ELM')

%saveas(gcf,'YELM_Diabetes_ELM_test','fig')
saveas(gcf,'YELM_Diabetes_ELM_test','png')
saveas(gcf,'YELM_Diabetes_ELM_test','eps')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% Plot the accuracy rate curve of YELM  %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
plot(1:Numberoftesttime,YELM_train_time)
title('Learning time of YELM')

%saveas(gcf,'YELM_Diabetes_YELM_time','fig')
saveas(gcf,'YELM_Diabetes_YELM_time','png')
saveas(gcf,'YELM_Diabetes_YELM_time','eps')

figure
plot(1:Numberoftesttime,YELM_train)
title('Training accuracy of YELM')

%saveas(gcf,'YELM_Diabetes_YELM_train','fig')
saveas(gcf,'YELM_Diabetes_YELM_train','png')
saveas(gcf,'YELM_Diabetes_YELM_train','eps')

figure
plot(1:Numberoftesttime,YELM_test)
title('Testing accuracy of YELM')

%saveas(gcf,'YELM_Diabetes_YELM_test','fig')
saveas(gcf,'YELM_Diabetes_YELM_test','png')
saveas(gcf,'YELM_Diabetes_YELM_test','eps')

save Diabetes_mean_YELM.mat