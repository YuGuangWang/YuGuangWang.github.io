%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% EELM for Diabetes %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear,clc
close all
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Type==0 for regression; Type==1 for classification
Type=1;
NumberofNeurons=20;
%Numberofdata=300;
Numberoftesttime=20;
ActivationFunction='sig';
%%%%%%%%%%% Obtain Random Dataset
diabetes5_data;     %   randomly generate new training and testing data for every trial of simulation
TrainingData_File='diabetes_train';
TestingData_File='diabetes_test';
%ablone_data('AbloneData1');
%%%%%%%%%%% Load Draining Dataset
train_data=load(TrainingData_File);
T=train_data(:,1)';
P=train_data(:,2:size(train_data,2))';
clear train_data;                                   %   Release raw training data array
%%%%%%%%%%% Load Desting Dataset
test_data=load(TestingData_File);
TV.T=test_data(:,1)';
TV.P=test_data(:,2:size(test_data,2))';
clear test_data;                                    %   Release raw testing data array


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%   Learn by EELM   %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
EELM_test=zeros(Numberoftesttime,1);
EELM_train=zeros(Numberoftesttime,1);
EELM_train_time=zeros(Numberoftesttime,1);
EELM_testing_time=zeros(Numberoftesttime,1);
EELM_TY=[];
EELM_Y=[];
wb = waitbar(0,'1','Name','EELM...');    


for rnd = 1 : Numberoftesttime
    
    waitbar(rnd/Numberoftesttime,wb,sprintf('%d',rnd));
    
    diabetes5_data;     %   randomly generate new training and testing data for every trial of simulation

    fprintf('\n====== EELM trial %d ======\n',rnd);
    [learn_time, test_time, train_accuracy, test_accuracy, EELM_Y_temp, EELM_TY_temp] =...
        EELM(TrainingData_File,TestingData_File,1,NumberofNeurons,ActivationFunction);
    EELM_test(rnd,1)=test_accuracy;
    EELM_train(rnd,1)=train_accuracy;
    EELM_train_time(rnd,1)=learn_time;
    EELM_testing_time(rnd,1)=test_time;
    EELM_TY=[EELM_TY EELM_TY_temp'];
    EELM_Y=[EELM_Y,EELM_Y_temp'];
end
close(wb);

fprintf('\n====== EELM result summary ======\n');
EELM_AverageTrainingTime=mean(EELM_train_time)
EELM_StandardDeviationofTrainingTime=std(EELM_train_time)
EELM_AvergeTestingTime=mean(EELM_testing_time)
EELM_StandardDeviationofTestingTime=std(EELM_testing_time)
EELM_AverageTrainingAccuracy=mean(EELM_train)
EELM_StandardDeviationofTrainingAccuracy=std(EELM_train)
EELM_AverageTestingAccuracy=mean(EELM_test)
EELM_StandardDeviationofTestingAccuracy=std(EELM_test)
EELM_TY_0=mean(EELM_TY');
EELM_Y_0=mean(EELM_Y');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%   Training by ELM   %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ELM_test=zeros(Numberoftesttime,1);
ELM_train=zeros(Numberoftesttime,1);
ELM_train_time=zeros(Numberoftesttime,1);
ELM_testing_time=zeros(Numberoftesttime,1);
ELM_TY=[];
ELM_Y=[];
wb = waitbar(0,'1','Name','ELM...');    


for rnd = 1 : Numberoftesttime
    
    waitbar(rnd/Numberoftesttime,wb,sprintf('%d',rnd));
    
    diabetes5_data;     %   randomly generate new training and testing data for every trial of simulation

    fprintf('\n====== ELM trial %d ======\n',rnd);
    [learn_time, test_time, train_accuracy, test_accuracy, ELM_Y_temp, ELM_TY_temp] =...
        ELM(TrainingData_File,TestingData_File,1,NumberofNeurons,ActivationFunction);
    ELM_test(rnd,1)=test_accuracy;
    ELM_train(rnd,1)=train_accuracy;
    ELM_train_time(rnd,1)=learn_time;
    ELM_testing_time(rnd,1)=test_time;
    ELM_TY=[ELM_TY ELM_TY_temp'];
    ELM_Y=[ELM_Y,ELM_Y_temp'];
end
close(wb);

fprintf('\n====== ELM result summary ======\n');
ELM_AverageTrainingTime=mean(ELM_train_time)
ELM_StandardDeviationofTrainingTime=std(ELM_train_time)
ELM_AvergeTestingTime=mean(ELM_testing_time)
ELM_StandardDeviationofTestingTime=std(ELM_testing_time)
ELM_AverageTrainingAccuracy=mean(ELM_train)
ELM_StandardDeviationofTrainingAccuracy=std(ELM_train)
ELM_AverageTestingAccuracy=mean(ELM_test)
ELM_StandardDeviationofTestingAccuracy=std(ELM_test)
ELM_TY_0=mean(ELM_TY');
ELM_Y_0=mean(ELM_Y');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% Plot the accuracy rate curve of ELM  %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
plot(1:Numberoftesttime,ELM_train_time)
title('Learning time of ELM')

%saveas(gcf,'EELM_Diabetes_ELM_time','fig')
saveas(gcf,'EELM_Diabetes_ELM_time','png')
saveas(gcf,'EELM_Diabetes_ELM_time','eps')

figure
plot(1:Numberoftesttime,ELM_train)
title('Training accuracy of ELM')

%saveas(gcf,'EELM_Diabetes_ELM_train','fig')
saveas(gcf,'EELM_Diabetes_ELM_train','png')
saveas(gcf,'EELM_Diabetes_ELM_train','eps')

figure
plot(1:Numberoftesttime,ELM_test)
title('Testing accuracy of ELM')

%saveas(gcf,'EELM_Diabetes_ELM_test','fig')
saveas(gcf,'EELM_Diabetes_ELM_test','png')
saveas(gcf,'EELM_Diabetes_ELM_test','eps')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% Plot the accuracy rate curve of EELM  %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
plot(1:Numberoftesttime,EELM_train_time)
title('Learning time of EELM')

%saveas(gcf,'EELM_Diabetes_EELM_time','fig')
saveas(gcf,'EELM_Diabetes_EELM_time','png')
saveas(gcf,'EELM_Diabetes_EELM_time','eps')

figure
plot(1:Numberoftesttime,EELM_train)
title('Training accuracy of EELM')

%saveas(gcf,'EELM_Diabetes_EELM_train','fig')
saveas(gcf,'EELM_Diabetes_EELM_train','png')
saveas(gcf,'EELM_Diabetes_EELM_train','eps')

figure
plot(1:Numberoftesttime,EELM_test)
title('Testing accuracy of EELM')

%saveas(gcf,'EELM_Diabetes_EELM_test','fig')
saveas(gcf,'EELM_Diabetes_EELM_test','png')
saveas(gcf,'EELM_Diabetes_EELM_test','eps')

save Diabetes_mean_EELM.mat