function [TrainingTime, TestingTime, TrainingAccuracy, TestingAccuracy, Y, TY] = EELM(TrainingData_File, TestingData_File, EELM_Type, NumberofHiddenNeurons,ActivationFunction)

% Usage: elm(TrainingData_File, TestingData_File, EELM_Type, NumberofHiddenNeurons, ActivationFunction)
% OR:    [TrainingTime, TestingTime, TrainingAccuracy, TestingAccuracy] = elm(TrainingData_File, TestingData_File, EELM_Type, NumberofHiddenNeurons)
%
% Input:
% TrainingData_File     - Filename of training data set
% TestingData_File      - Filename of testing data set
% EELM_Type              - 0 for regression; 1 for (both binary and multi-classes) classification
% NumberofHiddenNeurons - Number of hidden neurons assigned to the ELM
% ActivationFunction    - Type of activation function:
%                           'sig' for Sigmoidal function
%                           'sin' for Sine function
%                           'hardlim' for Hardlim function
%                           'tribas' for Triangular basis function
%                           'radbas' for Radial basis function (for additive type of SLFNs instead of RBF type of SLFNs)
%
% Output: 
% TrainingTime          - Time (seconds) spent on training ELM
% TestingTime           - Time (seconds) spent on predicting ALL testing data
% TrainingAccuracy      - Training accuracy: 
%                           RMSE for regression or correct classification rate for classification
% TestingAccuracy       - Testing accuracy: 
%                           RMSE for regression or correct classification rate for classification
%
% MULTI-CLASSE CLASSIFICATION: NUMBER OF OUTPUT NEURONS WILL BE AUTOMATICALLY SET EQUAL TO NUMBER OF CLASSES
% FOR EXAMPLE, if there are 7 classes in all, there will have 7 output
% neurons; neuron 5 has the highest output means input belongs to 5-th class
%
% Sample1 regression: [TrainingTime, TestingTime, TrainingAccuracy, TestingAccuracy] = elm('sinc_train', 'sinc_test', 0, 20, 'sig')
% Sample2 classification: elm('diabetes_train', 'diabetes_test', 1, 20, 'sig')
%
    %%%%    Authors:    MR QIN-YU ZHU AND DR GUANG-BIN HUANG
    %%%%    NANYANG TECHNOLOGICAL UNIVERSITY, SINGAPORE
    %%%%    EMAIL:      EGBHUANG@NTU.EDU.SG; GBHUANG@IEEE.ORG
    %%%%    WEBSITE:    http://www.ntu.edu.sg/eee/icis/cv/egbhuang.htm
    %%%%    DATE:       APRIL 2004

%%%%%%%%%%% Macro definition
REGRESSION=0;
CLASSIFIER=1;

%%%%%%%%%%% Load training dataset
train_data=load(TrainingData_File);
T=train_data(:,1)';
P=train_data(:,2:size(train_data,2))';
clear train_data;                                   %   Release raw training data array

%%%%%%%%%%% Load testing dataset
test_data=load(TestingData_File);
TV.T=test_data(:,1)';
TV.P=test_data(:,2:size(test_data,2))';
clear test_data;                                    %   Release raw testing data array

NumberofTrainingData=size(P,2);
NumberofTestingData=size(TV.P,2);
Dimention=size(P,1);
%NumberofInputNeurons=size(P,1);

if EELM_Type~=REGRESSION
    %%%%%%%%%%%% Preprocessing the data of classification
    sorted_target=sort(cat(2,T,TV.T),2);
    label=zeros(1,1);                               %   Find and save in 'label' class label from training and testing data sets
    label(1,1)=sorted_target(1,1);
    j=1;
    for i = 2:(NumberofTrainingData+NumberofTestingData)
        if sorted_target(1,i) ~= label(1,j)
            j=j+1;
            label(1,j) = sorted_target(1,i);
        end
    end
    number_class=j;
    NumberofOutputNeurons=number_class;
    
    %%%%%%%%%% Processing the targets of training
    temp_T=zeros(NumberofOutputNeurons, NumberofTrainingData);
    for i = 1:NumberofTrainingData
        for j = 1:number_class
            if label(1,j) == T(1,i)
                break; 
            end
        end
        temp_T(j,i)=1;
    end
    T=temp_T*2-1;

    %%%%%%%%%% Processing the targets of testing
    temp_TV_T=zeros(NumberofOutputNeurons, NumberofTestingData);
    for i = 1:NumberofTestingData
        for j = 1:number_class
            if label(1,j) == TV.T(1,i)
                break; 
            end
        end
        temp_TV_T(j,i)=1;
    end
    TV.T=temp_TV_T*2-1;

end                                                 %   end if of EELM_Type

%%%%%%%%%%% Calculate weights & biases
start_time_train=cputime;

%%%%%%%%%%% Random generate input weights InputWeight (w_i) and biases BiasofHiddenNeurons (b_i) of hidden neurons
%InputWeight=rand(NumberofHiddenNeurons,NumberofInputNeurons)*2-1;
%BiasofHiddenNeurons=rand(NumberofHiddenNeurons,1);
%%%%%%%%%%% Calculate the weights W and bias b by Gaussian function
%%%%%%%%%%% G(x)=exp(x)
% Input: P is a  matrix with n rows and d colums
%clear
%clc
%load('P')
% Sorting Inputs of Samples (colums of P) by Dictionary Order

%% Initialization
eps1=0.1;
tempP1=min(P,[],2);
ind=ones(1,NumberofTrainingData);
tempP=tempP1(:,ind);
%clear tempP1
P=P-tempP+eps1;
clear tempP

%tempP1=min(TV.P,[],2);
ind=ones(1,NumberofTestingData);
tempP=tempP1(:,ind);
clear tempP1
TV.P=TV.P-tempP+eps1;
clear tempP eps1
%% Get NumberofHiddenNeurons inputs for inputweights and bias calculation
tempP=P(:,1:NumberofHiddenNeurons);
%index_sort=size(tempP,2):-1:1;
%tempP=sortrows(tempP,index_sort);
%w_1=1./max(abs(tempP));
%P_1=[];
%y_1=[];
%for i=1:size(tempP,1)
%    P_1=[P_1' (tempP(i,:).*w_1)']';
%end
%for i=2:size(tempP,1)
%        y_temp=abs(P_1(i,:)-P_1(i-1,:));
%       y_1=[y_1' y_temp']';
%end
%y_1=y_1+eps.*ones(size(y_1));
%m=floor(-log10(min(y_1)))+3;
%w_2=zeros(size(w_1));
%for j=1:size(tempP,2)
%    w_2(j)=w_1(j)*10^(sum(m(1:j)));
%end

%% The calculation of InputWeights and Bias

% Calculate weights
xmin=min(tempP,[],2);
xmax=max(tempP,[],2);
step=zeros(Dimention,1);
tempP1=abs(tempP(:,2:end)-tempP(:,1:end-1));
for j=1:Dimention
    temp1=tempP1(j,:);
    temp1(temp1==0)=[];
    step(j)=min([temp1 1]);
end
clear temp1 tempP1
w_2=zeros(Dimention,1);
w_2(1)=1./(xmin(1).*step(1));
tempw=1./step(1);
for j=2:Dimention
    tempw=tempw.*(xmax(j-1)./xmin(j-1)).*(1./step(j));
    w_2(j)=1./xmin(j).*tempw;
end
clear tempw xmin xmax step
tempP1=zeros(1,NumberofHiddenNeurons);
for j=1:length(tempP1)
    tempP1(j)=w_2'*P(:,j);
end
[~,indextempP1]=sort(tempP1);
tempP=tempP(:,indextempP1);
P(:,1:NumberofHiddenNeurons)=P(:,indextempP1);
T(1:NumberofHiddenNeurons)=T(indextempP1);
%TV.P(:,1:NumberofHiddenNeurons)=TV.P(:,indextempP1);
%TV.T(1:NumberofHiddenNeurons)=TV.T(indextempP1);
clear indextempP1 tempP1
%W=w_2;
% Calculate M: maximum of g(x); x_0: maximal point; a: the range of x
% G(x)<M/(2.*n.^2); dist
%tempP=tempP';
%M=1;
x_0=0;
a=max([2.*abs(log(NumberofHiddenNeurons)) 1])+1; 
dist=max([a-x_0 x_0+a]);
W=zeros(size(tempP));
for i=2:NumberofHiddenNeurons-1
    k_temp=2.*dist./min([dot(w_2,tempP(:,i+1)-tempP(:,i)) dot(w_2,tempP(:,i)-tempP(:,i-1))]);
    W(:,i)=k_temp.*w_2;
end
W(:,1)=W(:,2);
W(:,end)= W(:,end-1);
b=zeros(NumberofHiddenNeurons,1);
for i=1:NumberofHiddenNeurons
    b(i)=x_0-dot(W(:,i),tempP(:,i));
end
InputWeight=W';
BiasofHiddenNeurons=b;
clear w_1 P_1 y_1 y_temp m w_2 M x_0 a dist W k_temp b tempP;                      %   Release temporary variates M x_0 a dist W k_temp and b
tempH=InputWeight*P;
clear P;                                            %   Release input of training data 
ind=ones(1,size(tempH,2));
BiasMatrix=BiasofHiddenNeurons(:,ind);              %   Extend the bias matrix BiasofHiddenNeurons to match the demention of H
tempH=tempH+BiasMatrix;

%%%%%%%%%%% Calculate hidden neuron output matrix H
switch ActivationFunction
   case {'sig','sigmoid'}
        %%%%%%% Sigmoid 
       H = 1 ./ (1 + exp(-tempH));
   case {'sin','sine'}
        %%%%%%% Sine
       H = sin(tempH);    
   case {'hardlim'}
        %%%%%%% Hard Limit
       H = double(hardlim(tempH));
   case {'tribas'}
        %%%%%%% Triangular basis function
       H = tribas(tempH);
    case {'Gaussian'}
        %%%%%%%% Radial basis function
        H = exp(-tempH.^2);
        %%%%%%%% More activation functions can be added here                
end
%H = gaussfun(tempH);
%H = radbas(tempH);
clear tempH;                                        %   Release the temparary array for calculation of hidden neuron output matrix H

%%%%%%%%%%% Calculate output weights OutputWeight (beta_i)
%OutputWeight=pinv(H') * T';                        % slower implementation
OutputWeight=(H * H')\H * T';                         % faster implementation
end_time_train=cputime;

%%%
%%%
%%%
TrainingTime=end_time_train-start_time_train;       %   Calculate CPU time (seconds) spent for training ELM

%%%%%%%%%%% Calculate the training accuracy
Y=(H' * OutputWeight)';                             %   Y: the actual output of the training data
if EELM_Type == REGRESSION
    TrainingAccuracy=sqrt(mse(T - Y))              %   Calculate training accuracy (RMSE) for regression case
end
clear H;

%%%%%%%%%%% Calculate the output of testing input
start_time_test=cputime;
tempH_test=InputWeight*TV.P;
clear TV.P;             %   Release input of testing data             
ind=ones(1,NumberofTestingData);
BiasMatrix=BiasofHiddenNeurons(:,ind);              %   Extend the bias matrix BiasofHiddenNeurons to match the demention of H
tempH_test=tempH_test + BiasMatrix;
switch ActivationFunction
   case {'sig','sigmoid'}
        %%%%%%% Sigmoid 
       H_test = 1 ./ (1 + exp(-tempH_test));
   case {'sin','sine'}
        %%%%%%% Sine
       H_test = sin(tempH_test);        
   case {'hardlim'}
        %%%%%%% Hard Limit
       H_test = hardlim(tempH_test);        
   case {'tribas'}
        %%%%%%% Triangular basis function
       H_test = tribas(tempH_test);        
    case {'Gaussian'}
        %%%%%%%% Radial basis function
        H_test = exp(-tempH_test.^2);        
        %%%%%%%% More activation functions can be added here        
end

%H_test = gaussfun(tempH_test);                      %   H_test: matrix of coefficients by Gaussian Function
%H_test = radbas(tempH_test);
TY=(H_test' * OutputWeight)';                       %   TY: the actual output of the testing data
end_time_test=cputime;
%%%
%%%
%%%
TestingTime=end_time_test-start_time_test;           %   Calculate CPU time (seconds) spent by ELM predicting the whole testing data

if EELM_Type == REGRESSION
    TestingAccuracy = sqrt(mse(TV.T - TY))            %   Calculate testing accuracy (RMSE) for regression case
end

if EELM_Type == CLASSIFIER
%%%%%%%%%% Calculate training & testing classification accuracy
    MissClassificationRate_Training=0;
    MissClassificationRate_Testing=0;

    for i = 1 : size(T, 2)
        [~, label_index_expected]=max(T(:,i));
        [~, label_index_actual]=max(Y(:,i));
        if label_index_actual~=label_index_expected
            MissClassificationRate_Training=MissClassificationRate_Training+1;
        end
    end
    %%%
%%%
%%%
    TrainingAccuracy = 1-MissClassificationRate_Training/size(T,2)
    for i = 1 : size(TV.T, 2)
        [~, label_index_expected]=max(TV.T(:,i));
        [~, label_index_actual]=max(TY(:,i));
        if label_index_actual~=label_index_expected
            MissClassificationRate_Testing=MissClassificationRate_Testing+1;
        end
    end
    %%%
%%%
%%%
    TestingAccuracy=1-MissClassificationRate_Testing/size(TV.T,2)  
end